package cts.nan.catalin.g1078.main;

import cts.nan.catalin.g1078.pattern.state.CerereStudent;

public class MainState {

	public static void main(String[] args) {
		
		CerereStudent cerere = new CerereStudent("ceva", "Ion");
		cerere.trimiterePeFlux();
	}

}
