package cts.nan.catalin.g1078.pattern.state;

public interface ICerereStudent {
    public void confirmare();

    public void verificare();

    public void avizareDecanat();

    public void respingere();
}