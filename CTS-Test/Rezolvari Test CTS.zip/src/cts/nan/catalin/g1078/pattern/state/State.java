package cts.nan.catalin.g1078.pattern.state;

public interface State {
	void modificaStare(CerereStudent cerere);
}
