package cts.nan.catalin.g1078.pattern.chainOfResponsability;

public class FisaAccident {
    String numePersoana;
    int varsta;
    boolean esteConstient;
    boolean sePoateDeplasa;
    boolean areMembreRupte;
    boolean areRaniDeschise;
}
