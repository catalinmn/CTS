package cts.nan.catalin.g1078.pattern.strategy;

public class ChallengeSalturi implements IChallenge{

	@Override
	public void startExercitiu(int nrRepetitii) {
		System.out.println("Realizati un numar de " + nrRepetitii + " repetitii pentru salturi");
		
	}

}
