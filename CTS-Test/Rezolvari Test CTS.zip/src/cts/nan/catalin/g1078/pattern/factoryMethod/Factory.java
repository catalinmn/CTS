package cts.nan.catalin.g1078.pattern.factoryMethod;


public interface Factory {
	ClipAbstract creeazaClip(String denumireClip, int durata);
}
