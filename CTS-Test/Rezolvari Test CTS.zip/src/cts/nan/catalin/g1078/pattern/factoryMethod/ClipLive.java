package cts.nan.catalin.g1078.pattern.factoryMethod;

public class ClipLive extends ClipAbstract {

	public ClipLive(String numeClip, int durata) {
		super(numeClip, durata);
		// TODO Auto-generated constructor stub
	}

}
