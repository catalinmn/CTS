package cts.nan.catalin.g1078.pattern.factoryMethod;

public class ClipTutorial extends ClipAbstract {

	public ClipTutorial(String numeClip, int durata) {
		super(numeClip, durata);	
	}

}
