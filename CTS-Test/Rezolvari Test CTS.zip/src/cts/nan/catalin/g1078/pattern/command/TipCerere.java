package cts.nan.catalin.g1078.pattern.command;

public enum TipCerere {
    NORMALA, URGENTA;
}