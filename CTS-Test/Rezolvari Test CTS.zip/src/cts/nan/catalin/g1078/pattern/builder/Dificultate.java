package cts.nan.catalin.g1078.pattern.builder;

public enum Dificultate {

	Incepator, Mediu, Avansat;
}
