package cts.nan.catalin.g1078.pattern.state;

public class StateRespinsa implements State{

	@Override
	public void modificaStare(CerereStudent cerere) {
		// TODO Auto-generated method stub
		
	}

}
