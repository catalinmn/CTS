package cts.nan.catalin.g1078.pattern.builder;

public interface IClasaFitness {

	ClasaFitness build();
}
