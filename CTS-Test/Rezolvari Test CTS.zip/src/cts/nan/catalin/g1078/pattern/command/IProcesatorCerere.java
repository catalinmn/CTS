package cts.nan.catalin.g1078.pattern.command;

public interface IProcesatorCerere {
    public void procesareCerere(TipCerere tip, String denumire);
}