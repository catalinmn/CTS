package cts.nan.catalin.g1078.pattern.strategy;

public interface IChallenge {
    public void startExercitiu(int nrRepetitii);
}