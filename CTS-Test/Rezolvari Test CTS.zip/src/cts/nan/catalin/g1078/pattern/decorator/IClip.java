package cts.nan.catalin.g1078.pattern.decorator;

public interface IClip {
    void pause();

    void stop();

    void resume();

    void start();
}